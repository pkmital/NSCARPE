ofxOpenCV2461
=============

ofxOpenCV linking against OpenCV 2.4.6.1, including libraries for OSX.  

CMake setting include: WITH_OPENCL = ON; WITH_EIGEN3 = ON.

Requires your project to link against ZLib and OpenCL.

Also includes a simple openframeworks project demonstrating how to use the new implementation of TV-L1 Optical Flow.

http://pkmital.com
